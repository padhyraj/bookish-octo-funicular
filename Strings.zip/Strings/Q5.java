public class Assignment5 {

	public static void main(String[] args) {
		String str = "Wipro";
		
		str = str.substring(1, str.length() - 1);
		
		System.out.println(str);
	}

}