package Interfaces.Assignment2;
package music;

public interface Playable {
	public void play();
}