class Dept 

{

    String empname,joinDate,department;

    int empno,basic,hra,it;

    char descode;


    Dept(int empno,String empname,String joinDate,char descode,String department,int basic ,int hra ,int it)

    {

        this.empno=empno;

        this.empname=empname;

        this.joinDate=joinDate;

        this.descode=descode;

        this.department=department;

        this.basic=basic;

        this.hra=hra;

        this.it=it;

    }

}

class Code

{

    char desigcode;

    String designation;

    int da;


    Code(char desigcode,String designation,int da)

    {

        this.desigcode=desigcode;

        this.designation=designation;

        this.da=da;

    }

}

public class hello

{

	public static void main(String[] args)
 
	{
	
	    int req=Integer.parseInt(args[0]);

	    int i,j,sal;


	Dept emp[]=new Dept[7];

        emp[0]=new Dept(1001,"Asish","12/06/1997",'e',"r&d",20000,8000,10000);

        emp[1]=new Dept(1002,"Shusma","14/07/1998",'c',"r&d",30000,12000,3000);

        emp[2]=new Dept(1003,"Rahul","3/06/1999",'k',"r&d",15000,6000,2000);

        emp[3]=new Dept(1004,"Chahat","21/02/2000",'r',"r&d",25000,8000,4000);

        emp[4]=new Dept(1005,"Ranjan","13/09/2001",'m',"r&d",30000,6000,5000);

        emp[5]=new Dept(1006,"Suman","22/10/1997",'e',"r&d",22000,10000,10000);

        emp[6]=new Dept(1007,"Tanmay","24/08/1997",'c',"r&d",10000,9000,12000);


        
Code dc[]=new Code[5];

        dc[0]=new Code('e',"engineer",20000);
 
        dc[1]=new Code('c',"consultant",20000);

        dc[2]=new Code('k',"clerk",20000);

        dc[3]=new Code('r',"receptionist",20000);

        dc[4]=new Code('m',"manager",20000);


    
        
      for(i=0;i<7;i++)

     		 {

        		  if(req==emp[i].empno)

          		  break;

     		 }

  
        		if(i!=7)

		        {
		
                for(j=0;j<5;j++)

               			 {

                    			 if(dc[j].desigcode==emp[i].descode)
			
                      break;

               			 }
 
         		 	 sal=emp[i].basic + emp[i].hra + dc[j].da -emp[i].it;

			            System.out.println("empno\tempname\tdepartment\tdesignation\tsalary\n");
			
            System.out.println(emp[i].empno +"\t"+emp[i].empname+"\t"+emp[i].department+"\t\t"+dc[j].designation+"\t"+sal);
			
}

			else
			{
				System.out.println("there is no employee id with:"+req);
			}

    }

}
