public class Person {
	public String name;
}
public class Teacher extends Person {
	public int salary;
	public String subject;
}
public class Student extends Person {
	public int roll;
}
public class CollegeStudent extends Student {
	public int year;
	public String major;
}
public class Assignment3 {

	public static void main(String[] args) {
	         
            Person p=new Person("rajnandini");
            Teacher t=new Teacher(10000,"math");
            Student s= new Student(201611306);
            CollegeStudent c=new CollegeStudent(2016,"physics");
            System.out.print(" "+p);
            

	}

}