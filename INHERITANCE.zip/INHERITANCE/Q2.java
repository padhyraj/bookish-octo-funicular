public class Person {
	protected String name;

	public Person(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + "]";
	}
	
	
}
public class Person {
	protected String name;

	public Person(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + "]";
	}
	
	
}
public class Assignment2 {

	public static void main(String[] args) {
		Employee employee = new Employee("John Doe", 5000000, 2019, "321a2sd1321ad");
		System.out.println(employee);
	}

}