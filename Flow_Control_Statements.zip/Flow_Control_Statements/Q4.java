import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
		char x = 'a';
		char y = 'e';
		
		if (x < y) {
			System.out.println(x + ", " + y);
		} else {
			System.out.println(y + ", " + x);
		}

	}

}