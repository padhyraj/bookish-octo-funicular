import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class Main {

    public static void main(String[] args) 
     {
         String gender=args[0];
         int a;
         a=Integer.parseInt(args[1]);
       if(gender=="Female" && (a>=1 && a<=58))
      {
           System.out.print("8.2%");
      }
       else if(gender=="Female" && (a>=59 && a<=100))
      {
            System.out.print("9.2%");
      }
       else if(gender=="Male" && (a>=1 && a<=58))
        {
            System.out.print("8.4%");
        }
        else if(gender=="Male" && (a>=59 && a<=100))
        {
            System.out.print("10.5%");  
        }
     }
     
}