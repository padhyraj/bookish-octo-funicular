package com.w3epic.wiprotraining.assignment1;
import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	CalcTest.class,
	StringmanipTest.class
})

public class Tester {
	
	public class AllTests {
		
	}
}