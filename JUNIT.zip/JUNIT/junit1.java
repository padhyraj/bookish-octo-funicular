import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

class MyUnitTest {

	@Test
	void testStringConcat() {
		MyUnit myUnit = new MyUnit();
		assertEquals("Result", "HelloWorld", myUnit.stringConcat("Hello", "World"));
	}

}

public class MyUnit {

	public String stringConcat(String a, String b) {
		return a + b;
	}

}