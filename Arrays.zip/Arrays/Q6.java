import java.util.Arrays;

public class Main {

	public static void main(String[] args) {
		int[] array = {48, 55, 68, 88, 101, 122};
		Arrays.sort(array);
		
		System.out.println(Arrays.toString(array));

	}

}