import java.util.*;
public class Main{

	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
		int[] haystack = {5, 4, 3, 9, 1, 7, 9};
		int needle = sc.nextInt();
		int index = -1;
		
		for (int i = 0; i < haystack.length; i++) {
			if (haystack[i] == needle) {
				index = i + 1;
				break;
			}
		}

		System.out.println(index);
	}

}