class SumNo
{
  public static void main(String[]args)
    {
       int a,b,sum;
        a=Integer.parseInt(args[0]);
       b=Integer.parseInt(args[1]);
        sum=a+b;
       System.out.println("sum of two no is"+sum);
    }
}